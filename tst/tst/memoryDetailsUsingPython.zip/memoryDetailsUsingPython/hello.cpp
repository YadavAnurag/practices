#include<stdio.h>
int main(){
	int m=1;
	while(m){
		m+=1;
		printf("%d\n",m);	
	}
}
