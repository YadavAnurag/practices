<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Document</title>
  </head>
  <body>
    <button onclick="record()" id="record">Record</button>
    <button onclick="stop()" id="stop">Stop</button>
    <button onclick="play()" id="play">Play</button>

    <script src="./recorderAPI.js"></script>
    <script>
      var recorder = null;
      var audio = null;
      const record = async () => {
        document.querySelector("#record").innerHTML = "Recording...";

        recorder = await recordAudio();
        recorder.start();
      };
      const stop = async () => {
        document.querySelector("#record").innerHTML = "Record";
        audio = await recorder.stop();
      };
      const play = async () => {
        document.querySelector("#play").innerHTML = "Playing...";
        audio.play();
        document.querySelector("#play").innerHTML = "Play";
      };
    </script>
  </body>
</html>
